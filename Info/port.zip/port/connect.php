<?php
mysql_connect('127.0.0.1','root','');
mysql_select_db('port');
?>
